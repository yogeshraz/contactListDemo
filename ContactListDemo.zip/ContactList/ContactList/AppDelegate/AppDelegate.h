//
//  AppDelegate.h
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>



@end

