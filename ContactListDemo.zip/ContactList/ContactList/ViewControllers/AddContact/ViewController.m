//
//  ViewController.m
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import "ViewController.h"
#import <GRDBObjc/GRDBObjc.h>
#import "SWRevealViewController.h"
#import "Helper.h"


@interface ViewController ()
{
    SWRevealViewController *revealController;
}
@property (nonatomic,strong) IBOutlet UIButton *btnMenu;
@property (nonatomic,strong) IBOutlet UIButton *btnSave;
@property (nonatomic,strong) IBOutlet UILabel *lblTitle;
@property (nonatomic,strong) IBOutlet UITextField *txtName;
@property (nonatomic,strong) IBOutlet UITextField *txtPhone;
@property (nonatomic,strong) IBOutlet UITextField *txtEmail;
@property (nonatomic,strong) IBOutlet UITextView *txtDetail;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupUI];
    [self flowType];
}

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = YES;
}

-(void)setupUI {
    [Helper setTextFiledBorder:self.txtName];
    [Helper setTextFiledBorder:self.txtEmail];
    [Helper setTextFiledBorder:self.txtPhone];
    [Helper setTextViewBorder:self.txtDetail];
}

-(void)flowType {
    if (self.contactEditObject != nil) {
        [self.btnMenu setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        [self.btnSave setTitle:@"Update" forState:UIControlStateNormal];
        self.lblTitle.text = @"Edit Contact";
        self.txtName.text = self.contactEditObject.name;
        self.txtEmail.text = self.contactEditObject.email;
        self.txtPhone.text = self.contactEditObject.phoneNumber;
        self.txtDetail.text = self.contactEditObject.detail;
    } else {
        [self setupLeftMenu];
    }
}

- (void)setupLeftMenu {
    revealController = [self revealViewController];
    [revealController panGestureRecognizer];
    [revealController tapGestureRecognizer];
    [self.btnMenu setImage:[UIImage imageNamed:@"menu"] forState:UIControlStateNormal];
}

#pragma mark - Press Skip
-(IBAction)menuBackBtnAction:(id)sender
{
    if (self.contactEditObject != nil) {
        [self.navigationController popViewControllerAnimated:YES];
    } else {
        [revealController revealToggleAnimated:YES];
    }
}

#pragma mark - Save and update contact detail
-(IBAction)saveBtnAction:(id)sender
{
    [self addUpdateContactInfo];
}

-(void)addUpdateContactInfo{
    if (self.txtName.text.length==0) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Please enter contact name." Button:@"Ok"];
        return;
    }
    if (self.txtPhone.text.length==0) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Please enter contact number." Button:@"Ok"];
        return;
    }
    
    if (self.txtPhone.text.length<10 || self.txtPhone.text.length>12) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Minimum contact number length is 10 and maximum length is 12." Button:@"Ok"];
        return;
    }
    
    if (self.txtEmail.text.length==0) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Please enter contact email address." Button:@"Ok"];
        return;
    }
    
    if ([Helper NSStringIsValidEmail:self.txtEmail.text]==NO) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Please enter contact vaild email address." Button:@"Ok"];
        return;
    }
    
    if (self.txtEmail.text.length==0) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Please enter contact email address." Button:@"Ok"];
        return;
    }
    
    if (self.txtDetail.text.length==0) {
        [Helper alertViewController:self Title:@"Alert" Message:@"Please enter contact detail." Button:@"Ok"];
        return;
    }
    
    if (self.contactEditObject != nil) {
        [Database UpdateContactDetail:self.txtName.text
                                email:self.txtEmail.text
                                phone:self.txtPhone.text
                               detail:self.txtDetail.text
                                   Id:[NSString stringWithFormat:@"%d",self.contactEditObject.Id]];
        [Helper alertViewControllerWithAction:self
                                        Title:@"Alert"
                                      Message:@"Contact info updated successfully"
                                       Button:@"Ok"
                            CompletionHandler:^{
            [self.navigationController popViewControllerAnimated:true];
        }];
    } else {
        [Database InsertContactDetail:self.txtName.text
                                email:self.txtEmail.text
                                phone:self.txtPhone.text
                               detail:self.txtDetail.text];
    }
    [self resetTxtFiled];
}

-(void)resetTxtFiled {
    [self.view endEditing:YES];
    [Helper alertViewController:self Title:@"Alert" Message:@"Contact info saved successfully" Button:@"Ok"];
    self.txtName.text = @"";
    self.txtEmail.text = @"";
    self.txtPhone.text = @"";
    self.txtDetail.text = @"";
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    // Prevent crashing undo bug – see note below.
    if (textField == self.txtPhone) {
        NSCharacterSet *set = [NSCharacterSet characterSetWithCharactersInString:@"1234567890 "];
        if([string rangeOfCharacterFromSet:set].location == NSNotFound && ![string isEqual:@""])
        {
            return NO;
        }
    }
    return YES;
}



@end
