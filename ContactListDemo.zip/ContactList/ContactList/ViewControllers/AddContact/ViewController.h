//
//  ViewController.h
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import <UIKit/UIKit.h>
#import "Database.h"
#import "ContactDataModel.h"

@interface ViewController : UIViewController

@property (assign, nonatomic) BOOL isEdit;
@property (nonatomic,strong) ContactDataModel *contactEditObject;

@end

