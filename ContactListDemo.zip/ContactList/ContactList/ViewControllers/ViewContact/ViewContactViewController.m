//
//  ViewContactViewController.m
//  ContactList
//
//  Created by Yogesh Raj on 24/06/23.
//

#import "ViewContactViewController.h"
#import "SWRevealViewController.h"
#import "Database.h"
#import "ContactCell.h"
#import "ContactDataModel.h"
#import "ViewController.h"

@interface ViewContactViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    SWRevealViewController *revealController;
    NSMutableArray *contactArray;
}
@property (nonatomic,strong) IBOutlet UIButton *btnMenu;
@property (nonatomic,strong) IBOutlet UITableView *tableView;

@end

@implementation ViewContactViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    [self setupLeftMenu];
}

- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = YES;
    contactArray = [Database getAllContacts];
    [self.tableView reloadData];
}

- (void)setupLeftMenu {
    revealController = [self revealViewController];
    [revealController panGestureRecognizer];
    [revealController tapGestureRecognizer];
}

#pragma mark - Press Skip
-(IBAction)menuBtnAction:(id)sender
{
    [revealController revealToggleAnimated:YES];
}

#pragma mark - UITableViewDataSource / UITableViewDelegates
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [contactArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellID = @"ContactCell";
    ContactCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    ContactDataModel *data = contactArray[indexPath.row];
    cell.lblName.text = data.name;
    cell.lblEmail.text = data.email;
    cell.lblPhone.text = data.phoneNumber;
    cell.lblDetail.text = data.detail;
    cell.btnEdit.tag = indexPath.row;
    [cell.btnEdit addTarget:self action:@selector(editContactInfoAction:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        ContactDataModel *data = contactArray[indexPath.row];
        [Database deleteContact:[NSString stringWithFormat:@"%d",data.Id]];
        [contactArray removeObjectAtIndex:indexPath.row];
        [tableView reloadData];
    }
}

#pragma mark - Press Back
-(IBAction)editContactInfoAction:(id)sender
{
    UIButton *btn = (UIButton *)sender;
    ContactDataModel *data = contactArray[btn.tag];
    ViewController *viewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    viewController.contactEditObject = data;
    viewController.isEdit = YES;
    [self.navigationController pushViewController:viewController animated:YES];
}

@end
