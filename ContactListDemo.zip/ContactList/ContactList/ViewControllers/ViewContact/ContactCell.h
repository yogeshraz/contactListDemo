//
//  ContactCell.h
//  ContactList
//
//  Created by Yogesh Raj on 24/06/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ContactCell : UITableViewCell

@property (nonatomic,strong) IBOutlet UIButton *btnEdit;
@property (nonatomic,strong) IBOutlet UILabel *lblName;
@property (nonatomic,strong) IBOutlet UILabel *lblPhone;
@property (nonatomic,strong) IBOutlet UILabel *lblEmail;
@property (nonatomic,strong) IBOutlet UILabel *lblDetail;

@end

NS_ASSUME_NONNULL_END
