//
//  MenuViewController.h
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface MenuViewController : UIViewController

@end

NS_ASSUME_NONNULL_END
