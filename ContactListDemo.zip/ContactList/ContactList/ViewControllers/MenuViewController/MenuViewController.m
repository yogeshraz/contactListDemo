//
//  MenuViewController.m
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import "MenuViewController.h"
#import "MenuCell.h"
#import "SWRevealViewController.h"
#import "ViewController.h"

@interface MenuViewController ()<UITableViewDelegate,UITableViewDataSource>
{
    NSArray *menuTitles;
}

@property (nonatomic,strong) IBOutlet UITableView *tableView;

@end

@implementation MenuViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    menuTitles = @[@"Add Contact",@"View Contact"];
}

#pragma mark - UITableViewDataSource / UITableViewDelegates
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [menuTitles count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    //NSDictionary *dict = [self.ItemsArray objectAtIndex:indexPath.row];
    
    static NSString *cellID = @"MenuCell";
    MenuCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    cell.title.text = menuTitles[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
   
    SWRevealViewController *revealController = self.revealViewController;
    UIViewController *newFrontController;
    
    if (indexPath.row == 0) {
        newFrontController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    } else if (indexPath.row == 1) {
        newFrontController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewContactViewController"];
    }
    
    UINavigationController *con = [[UINavigationController alloc] initWithRootViewController:newFrontController];
    [revealController setFrontViewPosition:FrontViewPositionLeft animated:YES];
    [revealController pushFrontViewController:con animated:YES];
}

@end
