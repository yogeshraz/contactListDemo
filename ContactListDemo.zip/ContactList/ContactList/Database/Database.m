//
//  Database.m
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import "Database.h"
#import "ContactDataModel.h"

@implementation Database

static FMDatabaseQueue *dbQueue;

+ (NSString *)DatabasePath {
    NSString *documentsPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) firstObject];
    NSString *dbPath = [documentsPath stringByAppendingPathComponent:@"db.sqlite"];
    return dbPath;
}

+ (void)createContactTable
{
    dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self DatabasePath]];
    [dbQueue inDatabase:^(FMDatabase *db) {
        if (![db tableExists:@"contact_list"]) {
            [db executeUpdate:@"CREATE TABLE contact_list(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,email TEXT,phone TEXT,detail TEXT)"];
        }
    }];
}

+ (void)InsertContactDetail:(NSString *)contactName email:(NSString *)contactEmail phone:(NSString *)contactPhoneNumber detail:(NSString *)contactDetail {
    [dbQueue inDatabase:^(FMDatabase *db) {
        dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self DatabasePath]];
        [db executeUpdate:@"INSERT INTO contact_list(name,email,phone,detail) VALUES (?,?,?,?)" withArgumentsInArray:@[contactName,contactEmail,contactPhoneNumber,contactDetail]];
    }];
}

+ (NSMutableArray *)getAllContacts {
    NSMutableArray *array = [[NSMutableArray alloc] init];
    [dbQueue inDatabase:^(FMDatabase *db) {
        dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self DatabasePath]];
        FMResultSet *result = [db executeQuery:@"select * from contact_list"];
            while ([result next]) {
                ContactDataModel *data = [[ContactDataModel alloc] init];
                data.Id = [[result stringForColumn:@"id"] intValue];
                data.name = [result stringForColumn:@"name"];
                data.email = [result stringForColumn:@"email"];
                data.detail = [result stringForColumn:@"detail"];
                data.phoneNumber = [result stringForColumn:@"phone"];
                [array addObject:data];
            }
            [result close];
    }];
    return array;
}

+ (void)UpdateContactDetail:(NSString *)contactName email:(NSString *)contactEmail phone:(NSString *)contactPhoneNumber detail:(NSString *)contactDetail Id:(NSString *)Id {
    [dbQueue inDatabase:^(FMDatabase *db) {
        dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self DatabasePath]];
        [db executeUpdate:@"UPDATE contact_list SET name= ?, email= ?, phone= ?, detail= ? WHERE id= ?" withArgumentsInArray:@[contactName,contactEmail,contactPhoneNumber,contactDetail,Id]];
    }];
}

+(void)deleteContact:(NSString *)Id {
    [dbQueue inDatabase:^(FMDatabase *db) {
        dbQueue = [FMDatabaseQueue databaseQueueWithPath:[self DatabasePath]];
        [db executeUpdate:@"DELETE FROM contact_list WHERE Id = ?" withArgumentsInArray:@[Id]];
    }];
}

@end
