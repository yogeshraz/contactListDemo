//
//  Database.h
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import <Foundation/Foundation.h>
#import <GRDBObjc/GRDBObjc.h>

NS_ASSUME_NONNULL_BEGIN

@interface Database : NSObject
+ (NSString *)DatabasePath;
+ (void)createContactTable;
+ (void)InsertContactDetail:(NSString *)contactName email:(NSString *)contactEmail phone:(NSString *)contactPhoneNumber detail:(NSString *)contactDetail;
+ (NSMutableArray *)getAllContacts;
+(void)deleteContact:(NSString *)Id;
+ (void)UpdateContactDetail:(NSString *)contactName email:(NSString *)contactEmail phone:(NSString *)contactPhoneNumber detail:(NSString *)contactDetail Id:(NSString *)Id;

@end

NS_ASSUME_NONNULL_END
