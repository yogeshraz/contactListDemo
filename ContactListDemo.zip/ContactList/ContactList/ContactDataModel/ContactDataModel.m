//
//  ContactDataModel.m
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import "ContactDataModel.h"

@implementation ContactDataModel


@end
