//
//  ContactDataModel.h
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ContactDataModel : NSObject

@property (strong, nonatomic) NSString *name;
@property (strong, nonatomic) NSString *email;
@property (strong, nonatomic) NSString *phoneNumber;
@property (strong, nonatomic) NSString *detail;
@property (assign, nonatomic) int Id;

@end

NS_ASSUME_NONNULL_END
