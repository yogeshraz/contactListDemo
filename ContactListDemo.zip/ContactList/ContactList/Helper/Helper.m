//
//  Helper.m
//  ContactList
//
//  Created by Yogesh Raj on 24/06/23.
//

#import "Helper.h"

@implementation Helper

#pragma mark - Email Validation
+(BOOL)NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = NO;
    NSString *stricterFilterString = @"^[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}$";
    NSString *laxString = @"^.+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2}[A-Za-z]*$";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

+(UITextField *)setTextFiledBorder:(UITextField *)text {
    UIView *paddingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 5, 50)];
    text.layer.borderWidth = 1;
    text.layer.cornerRadius = 4;
    text.layer.borderColor = [[UIColor grayColor] CGColor];
    text.leftView = paddingView;
    text.leftViewMode = UITextFieldViewModeAlways;
    return text;
}

+(UITextView *)setTextViewBorder:(UITextView *)txtView {
    txtView.layer.borderWidth = 1;
    txtView.layer.cornerRadius = 4;
    txtView.layer.borderColor = [[UIColor grayColor] CGColor];
    return txtView;
}


#pragma mark- AlertViewController
+(void)alertViewController:(UIViewController *)view Title:(NSString *)title Message:(NSString *)message Button:(NSString *)buttonTitle
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault handler:nil];
    
    [alert addAction:okAction];
    [view presentViewController:alert animated:YES completion:nil];
}

+(void)alertViewControllerWithAction:(UIViewController *)view Title:(NSString *)title Message:(NSString *)message Button:(NSString *)buttonTitle CompletionHandler:(void(^)(void))completionHandler
{
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *okAction = [UIAlertAction actionWithTitle:buttonTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * action) {
        completionHandler();
    }];
    [alert addAction:okAction];
    [view presentViewController:alert animated:YES completion:nil];
}

+(BOOL)NSStringIsValidMobile:(NSString *)phoneNumber {
    NSString *phoneRegex = @"^((\\+)|(00))[0-9]{6,14}$";
    NSPredicate *phoneTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", phoneRegex];
    BOOL phoneValidates = [phoneTest evaluateWithObject:phoneNumber];
    return phoneValidates;
}

@end
