//
//  Helper.h
//  ContactList
//
//  Created by Yogesh Raj on 24/06/23.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface Helper : NSObject
+(BOOL)NSStringIsValidEmail:(NSString *)checkString;
+(BOOL)NSStringIsValidMobile:(NSString *)phoneNumber;
+(UITextField *)setTextFiledBorder:(UITextField *)text;
+(UITextView *)setTextViewBorder:(UITextView *)txtView;
+(void)alertViewController:(UIViewController *)view Title:(NSString *)title Message:(NSString *)message Button:(NSString *)buttonTitle;
+(void)alertViewControllerWithAction:(UIViewController *)view Title:(NSString *)title Message:(NSString *)message Button:(NSString *)buttonTitle CompletionHandler:(void(^)(void))completionHandler;


@end

NS_ASSUME_NONNULL_END
