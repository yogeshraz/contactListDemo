//
//  SceneDelegate.h
//  ContactList
//
//  Created by Yogesh Raj on 23/06/23.
//

#import <UIKit/UIKit.h>
#import "SWRevealViewController.h"

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;
@property (strong, nonatomic) SWRevealViewController *viewController;
@end

